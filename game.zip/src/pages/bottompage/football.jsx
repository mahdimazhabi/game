import React from 'react';

const Page2 = () => {
  return (
    <div>
      <h1>Welcome to Page 2!</h1>
      <p>This is the second page of your application.</p>
    </div>
  );
}

export default Page2;
